package com.example;

public class PerformanceTester {
    public void performTask() {
        try {
            // Simulate some fast-running standard execution task
            Thread.sleep(50); 
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}