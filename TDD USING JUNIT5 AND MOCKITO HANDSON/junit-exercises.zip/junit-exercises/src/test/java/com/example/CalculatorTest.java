package com.example;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

public class CalculatorTest {

    private Calculator calculator;

    @Before
    public void setUp() {
        calculator = new Calculator();
    }

    @After
    public void tearDown() {
        calculator = null;
    }

    @Test
    public void testAddMethod() {
        int number1 = 10;
        int number2 = 20;
        int result = calculator.add(number1, number2);
        assertEquals(30, result);
    }

    @Test
    public void testSubtractMethod() {
        int number1 = 20;
        int number2 = 5;
        int result = calculator.subtract(number1, number2);
        assertEquals(15, result);
    }
}