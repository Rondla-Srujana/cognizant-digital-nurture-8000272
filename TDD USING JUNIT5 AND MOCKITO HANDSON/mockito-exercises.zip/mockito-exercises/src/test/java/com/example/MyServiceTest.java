package com.example;

import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MyServiceTest {

    // Exercise 1: Mocking and Stubbing
    @Test
    public void testExternalApi() {
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);
        when(mockApi.getData()).thenReturn("Mock Data");

        MyService service = new MyService(mockApi);
        String result = service.fetchData();

        assertEquals("Mock Data", result);
    }

    // Exercise 2: Verifying Interactions
    @Test
    public void testVerifyInteraction() {
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);
        MyService service = new MyService(mockApi);

        service.fetchData();

        verify(mockApi).getData();
    }

    // Exercise 3: Argument Matching
    @Test
    public void testArgumentMatching() {
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);
        MyService service = new MyService(mockApi);

        service.processAndSave("Specific Argument");

        // Verify with specific string matcher
        verify(mockApi).saveData(eq("Specific Argument"));
        
        // Example using any() argument matcher
        when(mockApi.getDataWithArg(anyString())).thenReturn("Matched data");
        String result = service.fetchDataWithArg("anyKey");
        assertEquals("Matched data", result);
    }

    // Exercise 4: Handling Void Methods
    @Test
    public void testHandlingVoidMethods() {
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);
        MyService service = new MyService(mockApi);

        // Stubbing a void method explicitly (optional unless changing default behavior)
        doNothing().when(mockApi).saveData(anyString());

        service.processAndSave("Test Void");

        verify(mockApi).saveData("Test Void");
    }

    // Exercise 5: Mocking and Stubbing with Multiple Returns
    @Test
    public void testMultipleReturns() {
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);
        // Returns "First Call" on first invocation, "Second Call" on the next
        when(mockApi.getData()).thenReturn("First Call").thenReturn("Second Call");

        MyService service = new MyService(mockApi);

        assertEquals("First Call", service.fetchData());
        assertEquals("Second Call", service.fetchData());
    }

    // Exercise 6: Verifying Interaction Order
    @Test
    public void testVerificationOrder() {
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);
        MyService service = new MyService(mockApi);

        // Triggering sequential calls
        service.fetchData();
        service.processAndSave("Ordered Data");

        // Verify order of operations
        InOrder inOrder = inOrder(mockApi);
        inOrder.verify(mockApi).getData();
        inOrder.verify(mockApi).saveData("Ordered Data");
    }

    // Exercise 7: Handling Void Methods with Exceptions
    @Test
    public void testVoidMethodWithException() throws Exception {
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);
        MyService service = new MyService(mockApi);

        // Stub void method to throw exception
        doThrow(new RuntimeException("API Failure")).when(mockApi).doSomething();

        Exception exception = assertThrows(RuntimeException.class, () -> {
            service.executeAction();
        });

        assertEquals("API Failure", exception.getMessage());
        verify(mockApi).doSomething();
    }
}