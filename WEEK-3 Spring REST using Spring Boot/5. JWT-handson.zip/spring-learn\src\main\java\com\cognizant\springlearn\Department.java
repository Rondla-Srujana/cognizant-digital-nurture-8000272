﻿package com.cognizant.springlearn;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class Department {
    @NotNull(message = "Department ID cannot be null")
    private Integer id;
    @NotBlank(message = "Department name cannot be blank")
    private String name;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}
