﻿package com.cognizant.springlearn.controller;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
public class AuthenticationController {
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationController.class);

    @GetMapping("/authenticate")
    public Map<String, String> authenticate() {
        LOGGER.info("START - Authentication emission endpoint trigger.");
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String user = auth.getName();
        
        long expirationMillis = System.currentTimeMillis() + 1200000; // 20 minutes expiration
        byte[] genericSecretKey = "EnterpriseSecureKeyTokenValidationContextContainerConfigStringMappingBytesDetailsProps!!".getBytes();
        
        String generatedToken = Jwts.builder()
                .subject(user)
                .issuedAt(new Date())
                .expiration(new Date(expirationMillis))
                .signWith(Keys.hmacShaKeyFor(genericSecretKey))
                .compact();
                
        Map<String, String> tokenMap = new HashMap<>();
        tokenMap.put("token", generatedToken);
        LOGGER.info("END - Authentication generated perfectly.");
        return tokenMap;
    }
}
