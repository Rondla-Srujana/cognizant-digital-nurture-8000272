﻿package com.cognizant.springlearn.controller;
import com.cognizant.springlearn.Country;
import com.cognizant.springlearn.service.CountryService;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.ArrayList;

@RestController
@RequestMapping("/countries")
public class CountryController {
    @Autowired private CountryService countryService;

    @GetMapping
    public ArrayList<Country> getAllCountries() { return countryService.getAllCountries(); }

    @GetMapping("/{code}")
    public Country getCountry(@PathVariable String code) throws CountryNotFoundException {
        return countryService.getCountry(code);
    }
    @PostMapping
    public Country addCountry(@RequestBody @Valid Country country) {
        countryService.addCountry(country);
        return country;
    }
}
