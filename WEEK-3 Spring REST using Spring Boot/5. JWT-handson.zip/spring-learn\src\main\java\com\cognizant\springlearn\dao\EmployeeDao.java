﻿package com.cognizant.springlearn.dao;
import com.cognizant.springlearn.Employee;
import com.cognizant.springlearn.service.exception.EmployeeNotFoundException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;

@Repository
public class EmployeeDao {
    private static ArrayList<Employee> EMPLOYEE_LIST;

    @SuppressWarnings("unchecked")
    public EmployeeDao() {
        ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
        EMPLOYEE_LIST = context.getBean("employeeList", ArrayList.class);
    }
    public ArrayList<Employee> getAllEmployees() { return EMPLOYEE_LIST; }
    public void updateEmployee(Employee employee) throws EmployeeNotFoundException {
        Employee existing = EMPLOYEE_LIST.stream()
                .filter(e -> e.getId() == employee.getId())
                .findFirst()
                .orElseThrow(EmployeeNotFoundException::new);
        existing.setName(employee.getName());
        existing.setSalary(employee.getSalary());
    }
    public void deleteEmployee(int id) throws EmployeeNotFoundException {
        Employee existing = EMPLOYEE_LIST.stream()
                .filter(e -> e.getId() == id)
                .findFirst()
                .orElseThrow(EmployeeNotFoundException::new);
        EMPLOYEE_LIST.remove(existing);
    }
}
