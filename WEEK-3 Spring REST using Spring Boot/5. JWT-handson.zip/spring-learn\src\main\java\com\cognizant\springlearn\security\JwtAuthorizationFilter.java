﻿package com.cognizant.springlearn.security;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.ArrayList;

public class JwtAuthorizationFilter extends OncePerRequestFilter {
    private static final Logger LOGGER = LoggerFactory.getLogger(JwtAuthorizationFilter.class);

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws IOException, ServletException {
        LOGGER.info("START - Intercepting query tracking header variables.");
        String header = request.getHeader("Authorization");

        if (header == null || !header.startsWith("Bearer ")) {
            LOGGER.info("No token metadata context payload found or prefix invalid - propagating cascade down filter chain.");
            filterChain.doFilter(request, response);
            return;
        }

        String actualToken = header.substring(7);
        try {
            byte[] keyBytes = "EnterpriseSecureKeyTokenValidationContextContainerConfigStringMappingBytesDetailsProps!!".getBytes();
            
            Claims extractedClaims = Jwts.parser()
                    .verifyWith(Keys.hmacShaKeyFor(keyBytes))
                    .build()
                    .parseSignedClaims(actualToken)
                    .getPayload();
                    
            String parsedUser = extractedClaims.getSubject();
            if (parsedUser != null) {
                UsernamePasswordAuthenticationToken verifiedTokenObj = 
                        new UsernamePasswordAuthenticationToken(parsedUser, null, new ArrayList<>());
                SecurityContextHolder.getContext().setAuthentication(verifiedTokenObj);
                LOGGER.info("JWT tracking context established successfully downstream for security profile user: {}", parsedUser);
            }
        } catch (Exception runtimeContextException) {
            LOGGER.error("Failed downstream verification of inbound token context schema payload details: {}", runtimeContextException.getMessage());
        }

        filterChain.doFilter(request, response);
    }
}
