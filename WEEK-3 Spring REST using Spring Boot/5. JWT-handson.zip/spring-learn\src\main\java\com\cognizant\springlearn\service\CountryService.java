﻿package com.cognizant.springlearn.service;
import com.cognizant.springlearn.Country;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;
import java.util.ArrayList;

@Service
public class CountryService {
    private static ArrayList<Country> COUNTRY_LIST;

    @SuppressWarnings("unchecked")
    public CountryService() {
        ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
        COUNTRY_LIST = context.getBean("countryList", ArrayList.class);
    }
    public ArrayList<Country> getAllCountries() { return COUNTRY_LIST; }
    public Country getCountry(String code) throws CountryNotFoundException {
        return COUNTRY_LIST.stream()
                .filter(c -> c.getCode().equalsIgnoreCase(code))
                .findFirst()
                .orElseThrow(CountryNotFoundException::new);
    }
    public void addCountry(Country country) { COUNTRY_LIST.add(country); }
}
