﻿package com.cognizant.springlearn;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import com.cognizant.springlearn.controller.CountryController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
public class SpringLearnApplicationTests {
    @Autowired private CountryController countryController;
    @Autowired private MockMvc mvc;

    @Test
    public void contextLoads() { assertNotNull(countryController); }

    @Test
    public void testAuthenticateEndpointSuccess() throws Exception {
        mvc.perform(get("/authenticate").with(httpBasic("user", "pwd")))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.token").exists());
    }

    @Test
    public void testAccessUnauthenticatedEndpointFails() throws Exception {
        mvc.perform(get("/countries"))
           .andExpect(status().isUnauthorized());
    }
}
