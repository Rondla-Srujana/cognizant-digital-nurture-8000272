﻿package com.cognizant.springlearn.controller;
import com.cognizant.springlearn.Country;
import com.cognizant.springlearn.service.CountryService;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.ArrayList;

@RestController
@RequestMapping("/countries")
public class CountryController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CountryController.class);

    @Autowired
    private CountryService countryService;

    @GetMapping("/default")
    public Country getCountryIndia() throws CountryNotFoundException {
        LOGGER.info("START - getCountryIndia()");
        Country country = countryService.getCountry("IN");
        LOGGER.info("END - getCountryIndia()");
        return country;
    }

    @GetMapping
    public ArrayList<Country> getAllCountries() {
        LOGGER.info("START - getAllCountries()");
        ArrayList<Country> countriesList = countryService.getAllCountries();
        LOGGER.info("END - getAllCountries()");
        return countriesList;
    }

    @GetMapping("/{code}")
    public Country getCountry(@PathVariable String code) throws CountryNotFoundException {
        LOGGER.info("START - getCountry() for code: {}", code);
        Country country = countryService.getCountry(code);
        LOGGER.info("END - getCountry()");
        return country;
    }

    @PostMapping
    public Country addCountry(@RequestBody @Valid Country country) {
        LOGGER.info("START - addCountry()");
        countryService.addCountry(country);
        LOGGER.info("END - addCountry() structural insertion mapping success. Resource details: {}", country);
        return country;
    }
}
