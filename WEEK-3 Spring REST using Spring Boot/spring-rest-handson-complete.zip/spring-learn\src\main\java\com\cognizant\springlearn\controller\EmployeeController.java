﻿package com.cognizant.springlearn.controller;
import com.cognizant.springlearn.Employee;
import com.cognizant.springlearn.service.EmployeeService;
import com.cognizant.springlearn.service.exception.EmployeeNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.ArrayList;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeController.class);

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public ArrayList<Employee> getAllEmployees() {
        LOGGER.info("START - getAllEmployees()");
        ArrayList<Employee> list = employeeService.getAllEmployees();
        LOGGER.info("END - getAllEmployees()");
        return list;
    }

    @PutMapping
    public void updateEmployee(@RequestBody @Valid Employee employee) throws EmployeeNotFoundException {
        LOGGER.info("START - updateEmployee() with details: {}", employee);
        employeeService.updateEmployee(employee);
        LOGGER.info("END - updateEmployee()");
    }

    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable int id) throws EmployeeNotFoundException {
        LOGGER.info("START - deleteEmployee() with target identifier: {}", id);
        employeeService.deleteEmployee(id);
        LOGGER.info("END - deleteEmployee()");
    }
}
