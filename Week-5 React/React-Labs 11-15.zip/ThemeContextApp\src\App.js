﻿import React, { useState } from 'react';
import ThemeContext from './ThemeContext';
import EmployeesList from './EmployeesList';

function App() {
  const [theme, setTheme] = useState('light');
  return (
    <ThemeContext.Provider value={theme}>
      <div style={{ padding: '20px', background: theme === 'dark' ? '#333' : '#fff', color: theme === 'dark' ? '#fff' : '#000' }}>
        <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>Toggle Theme Style</button>
        <EmployeesList />
      </div>
    </ThemeContext.Provider>
  );
}
export default App;
