﻿import React, { useContext } from 'react';
import ThemeContext from './ThemeContext';

function EmployeeCard({ employee }) {
  const theme = useContext(ThemeContext);
  return (
    <div style={{ border: '1px solid gray', padding: '10px', marginTop: '10px' }}>
      <h4>{employee.name}</h4>
      <p>{employee.role}</p>
      <button style={{ backgroundColor: theme === 'dark' ? '#fff' : '#000', color: theme === 'dark' ? '#000' : '#fff' }}>
        View Details ({theme})
      </button>
    </div>
  );
}
export default EmployeeCard;
