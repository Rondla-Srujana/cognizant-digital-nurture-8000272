﻿import React from 'react';
import EmployeeCard from './EmployeeCard';

function EmployeesList() {
  const employees = [{ id: 101, name: 'Alice Smith', role: 'Frontend Engineer' }];
  return (
    <div>
      <h2>Employees List</h2>
      {employees.map(emp => <EmployeeCard key={emp.id} employee={emp} />)}
    </div>
  );
}
export default EmployeesList;
