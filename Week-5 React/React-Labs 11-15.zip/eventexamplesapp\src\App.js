﻿import React, { useState } from 'react';
import CurrencyConvertor from './CurrencyConvertor';

function App() {
  const [counter, setCounter] = useState(0);
  const handleIncrement = () => { setCounter(prev => prev + 1); sayHello(); };
  const handleDecrement = () => { setCounter(prev => prev - 1); };
  const sayHello = () => { alert("Hello! This is a static message triggered by incrementing."); };
  const sayWelcome = (msg) => { alert(`Action argument received: ${msg}`); };
  const handleSyntheticEvent = (e) => { alert(`Synthetic event type: ${e.type}. Message: I was clicked!`); };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Event Examples App</h1>
      <div style={{ border: '1px solid #ccc', padding: '15px', marginBottom: '20px' }}>
        <h3>Counter: {counter}</h3>
        <button onClick={handleIncrement}>Increment</button>
        <button onClick={handleDecrement} style={{ marginLeft: '10px' }}>Decrement</button>
      </div>
      <div style={{ border: '1px solid #ccc', padding: '15px', marginBottom: '20px' }}>
        <h3>Custom Arguments & Synthetic Events</h3>
        <button onClick={() => sayWelcome('welcome')}>Say Welcome</button>
        <button onClick={handleSyntheticEvent} style={{ marginLeft: '10px' }}>OnPress (Synthetic)</button>
      </div>
      <CurrencyConvertor />
    </div>
  );
}
export default App;
