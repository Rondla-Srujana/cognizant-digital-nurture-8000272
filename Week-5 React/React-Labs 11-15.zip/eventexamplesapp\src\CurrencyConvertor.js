﻿import React, { useState } from 'react';

function CurrencyConvertor() {
  const [rupees, setRupees] = useState('');
  const [euros, setEuros] = useState(null);
  const handleSubmit = (e) => {
    e.preventDefault();
    const result = parseFloat(rupees) * 0.011;
    setEuros(result.toFixed(2));
  };
  return (
    <div style={{ border: '1px solid #ccc', padding: '15px' }}>
      <h3>Currency Convertor (INR to EUR)</h3>
      <form onSubmit={handleSubmit}>
        <input type="number" value={rupees} onChange={(e) => setRupees(e.target.value)} required />
        <button type="submit" style={{ marginLeft: '10px' }}>Convert</button>
      </form>
      {euros !== null && !isNaN(euros) && <p>Amount in Euro: €{euros}</p>}
    </div>
  );
}
export default CurrencyConvertor;
