﻿import React, { useState } from 'react';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const flightDetails = [
    { id: 1, flightNo: 'AI-101', route: 'Delhi to Mumbai', departure: '10:00 AM' },
    { id: 2, flightNo: '6E-204', route: 'Bangalore to Hyderabad', departure: '02:30 PM' }
  ];
  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Ticket Booking App</h1>
      <button onClick={() => setIsLoggedIn(!isLoggedIn)}>{isLoggedIn ? 'Logout' : 'Login'}</button>
      <h2>Available Flights</h2>
      <table border="1" cellPadding="10" style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead><tr><th>Flight No</th><th>Route</th><th>Departure</th><th>Action</th></tr></thead>
        <tbody>
          {flightDetails.map(f => (
            <tr key={f.id}>
              <td>{f.flightNo}</td><td>{f.route}</td><td>{f.departure}</td>
              <td>{isLoggedIn ? <button onClick={() => alert('Booked!')}>Book Ticket</button> : <span style={{color:'red'}}>Login required</span>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export default App;
