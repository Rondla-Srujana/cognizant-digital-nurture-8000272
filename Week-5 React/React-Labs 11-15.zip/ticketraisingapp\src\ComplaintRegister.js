﻿import React, { useState } from 'react';

function ComplaintRegister() {
  const [name, setName] = useState('');
  const [complaint, setComplaint] = useState('');
  const handleSubmit = (e) => {
    e.preventDefault();
    const refNum = Math.floor(100000 + Math.random() * 900000);
    alert(`Thank you ${name}!\nComplaint Registered.\nReference Number: REF-${refNum}`);
    setName(''); setComplaint('');
  };
  return (
    <form onSubmit={handleSubmit} style={{ padding: '20px', maxWidth: '400px' }}>
      <label>Employee Name: <input type="text" value={name} onChange={e => setName(e.target.value)} required /></label><br/><br/>
      <label>Complaint: <textarea value={complaint} onChange={e => setComplaint(e.target.value)} required /></label><br/><br/>
      <button type="submit">Submit Complaint</button>
    </form>
  );
}
export default ComplaintRegister;
