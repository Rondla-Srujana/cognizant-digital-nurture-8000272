﻿import React from 'react';
function CohortDetails({ cohort }) {
  if (!cohort) return null;
  return (
    <div className="cohort-card" style={{ border: '1px solid #aaa', padding: '15px', margin: '10px' }}>
      <h3>{cohort.code}</h3>
      <p>Program: {cohort.program}</p>
    </div>
  );
}
export default CohortDetails;
