﻿import React from 'react';
import { shallow, mount } from 'enzyme';
import CohortDetails from './CohortDetails';

describe('Cohort Details Component', () => {
  const dummyCohort = { code: 'CH-2026', program: 'React Specialist' };

  test('should create the component', () => {
    const wrapper = shallow(<CohortDetails cohort={dummyCohort} />);
    expect(wrapper.exists()).toBe(true);
  });

  test('should initialize the props', () => {
    const wrapper = mount(<CohortDetails cohort={dummyCohort} />);
    expect(wrapper.props().cohort).toEqual(dummyCohort);
  });

  test('should display cohort code in h3', () => {
    const wrapper = mount(<CohortDetails cohort={dummyCohort} />);
    expect(wrapper.find('h3').text()).toBe('CH-2026');
  });

  test('should always render same html', () => {
    const wrapper = shallow(<CohortDetails cohort={dummyCohort} />);
    expect(wrapper).toMatchSnapshot();
  });
});
