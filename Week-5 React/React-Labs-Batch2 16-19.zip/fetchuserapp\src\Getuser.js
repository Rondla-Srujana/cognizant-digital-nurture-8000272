﻿import React, { Component } from 'react';

class Getuser extends Component {
  constructor(props) {
    super(props);
    this.state = { user: null, loading: true };
  }

  async componentDidMount() {
    try {
      const response = await fetch('https://api.randomuser.me/');
      const data = await response.json();
      this.setState({ user: data.results[0], loading: false });
    } catch (error) {
      console.error("Error fetching user data:", error);
      this.setState({ loading: false });
    }
  }

  render() {
    const { user, loading } = this.state;
    if (loading) return <h3 style={{ textAlign: 'center' }}>Loading user profile...</h3>;
    if (!user) return <h3 style={{ textAlign: 'center' }}>Failed to retrieve data.</h3>;

    return (
      <div style={{ border: '1px solid #ccc', borderRadius: '8px', padding: '20px', maxWidth: '300px', margin: '40px auto', textAlign: 'center', fontFamily: 'sans-serif' }}>
        <h2>User Details</h2>
        <img src={user.picture.large} alt="User Profile" style={{ borderRadius: '50%', marginBottom: '15px' }} />
        <h3>{user.name.title} {user.name.first} {user.name.last}</h3>
        <p style={{ color: 'gray' }}>{user.email}</p>
      </div>
    );
  }
}

export default Getuser;
