﻿import React, { useState, useEffect } from 'react';
import GitClient from './GitClient';

function App() {
  const [repos, setRepos] = useState([]);
  useEffect(() => {
    const client = new GitClient();
    client.getRepositories('techiesyed').then(data => setRepos(data));
  }, []);

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Repositories for techiesyed</h2>
      <ul>{repos.map((name, i) => <li key={i}>{name}</li>)}</ul>
    </div>
  );
}
export default App;
