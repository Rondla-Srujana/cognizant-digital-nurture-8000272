﻿import axios from 'axios';
import GitClient from './GitClient';

jest.mock('axios');

describe('Git Client Tests', () => {
  test('should return repository names for techiesyed', async () => {
    const mockedRepos = [
      { name: 'react-hands-on' },
      { name: 'testing-workshop' }
    ];
    axios.get.mockResolvedValue({ data: mockedRepos });

    const client = new GitClient();
    const result = await client.getRepositories('techiesyed');

    expect(result).toEqual(['react-hands-on', 'testing-workshop']);
    expect(axios.get).toHaveBeenCalledWith('https://api.github.com/users/techiesyed/repos');
  });
});
