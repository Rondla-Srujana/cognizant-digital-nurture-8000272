﻿import React, { useState } from 'react';

function Register() {
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const validate = () => {
    let localErrors = {};
    if (formData.name.length < 5) {
      localErrors.name = "Name must have at least 5 characters.";
    }
    if (!formData.email.includes('@') || !formData.email.includes('.')) {
      localErrors.email = "Email must contain '@' and '.' characters.";
    }
    if (formData.password.length < 8) {
      localErrors.password = "Password must have at least 8 characters.";
    }
    return localErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length === 0) {
      alert("Registration Successful!");
      setErrors({});
      setFormData({ name: '', email: '', password: '' });
    } else {
      setErrors(validationErrors);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '400px', margin: 'auto', fontFamily: 'sans-serif' }}>
      <h2>Mail Register Form</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name:</label>
          <input type="text" name="name" value={formData.name} onChange={handleChange} style={{ width: '100%', padding: '8px' }} />
          {errors.name && <p style={{ color: 'red', fontSize: '13px' }}>{errors.name}</p>}
        </div><br/>
        <div>
          <label>Email:</label>
          <input type="text" name="email" value={formData.email} onChange={handleChange} style={{ width: '100%', padding: '8px' }} />
          {errors.email && <p style={{ color: 'red', fontSize: '13px' }}>{errors.email}</p>}
        </div><br/>
        <div>
          <label>Password:</label>
          <input type="password" name="password" value={formData.password} onChange={handleChange} style={{ width: '100%', padding: '8px' }} />
          {errors.password && <p style={{ color: 'red', fontSize: '13px' }}>{errors.password}</p>}
        </div><br/>
        <button type="submit" style={{ padding: '10px 15px', background: 'blue', color: 'white', border: 'none' }}>Register</button>
      </form>
    </div>
  );
}

export default Register;
