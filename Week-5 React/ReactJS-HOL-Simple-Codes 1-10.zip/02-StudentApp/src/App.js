function App() {
  return (
    <div>
      <h1>02-StudentApp</h1>
    </div>
  );
}
export default App;
