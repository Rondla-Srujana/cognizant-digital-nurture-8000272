function App() {
  return (
    <div>
      <h1>03-scorecalculatorapp</h1>
    </div>
  );
}
export default App;
