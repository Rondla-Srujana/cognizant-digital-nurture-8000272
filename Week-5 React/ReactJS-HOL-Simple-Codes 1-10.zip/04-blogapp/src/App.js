function App() {
  return (
    <div>
      <h1>04-blogapp</h1>
    </div>
  );
}
export default App;
