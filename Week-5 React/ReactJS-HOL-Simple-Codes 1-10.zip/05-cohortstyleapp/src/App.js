function App() {
  return (
    <div>
      <h1>05-cohortstyleapp</h1>
    </div>
  );
}
export default App;
