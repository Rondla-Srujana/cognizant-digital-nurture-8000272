function App() {
  return (
    <div>
      <h1>06-TrainersApp</h1>
    </div>
  );
}
export default App;
