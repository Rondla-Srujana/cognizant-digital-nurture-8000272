function App() {
  return (
    <div>
      <h1>07-shoppingapp</h1>
    </div>
  );
}
export default App;
