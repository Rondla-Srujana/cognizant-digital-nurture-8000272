function App() {
  return (
    <div>
      <h1>09-cricketapp</h1>
    </div>
  );
}
export default App;
