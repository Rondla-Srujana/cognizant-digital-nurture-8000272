function App() {
  return (
    <div>
      <h1>10-officespacerentalapp</h1>
    </div>
  );
}
export default App;
