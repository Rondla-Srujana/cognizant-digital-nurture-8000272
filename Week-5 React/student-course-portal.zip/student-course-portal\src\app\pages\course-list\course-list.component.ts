﻿import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseCardComponent } from '../../components/course-card/course-card.component';

@Component({
  selector: 'app-course-list',
  standalone: true,
  imports: [CommonModule, CourseCardComponent],
  templateUrl: './course-list.component.html',
  styleUrl: './course-list.component.css'
})
export class CourseListComponent {
  selectedCourseId: number | null = null;

  courses = [
    { id: 101, name: 'Introduction to Angular', code: 'CS-201', credits: 4 },
    { id: 102, name: 'Database Management Systems', code: 'CS-302', credits: 3 },
    { id: 103, name: 'Web Application Security', code: 'CS-405', credits: 4 },
    { id: 104, name: 'Cloud Computing Infrastructure', code: 'CS-412', credits: 3 },
    { id: 105, name: 'Data Structures and Algorithms', code: 'CS-102', credits: 4 }
  ];

  onEnroll(courseId: number): void {
    console.log('Enrolling in course: ' + courseId);
    this.selectedCourseId = courseId;
  }
}
