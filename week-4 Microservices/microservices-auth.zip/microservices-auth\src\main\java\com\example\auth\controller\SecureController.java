package com.example.auth.controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class SecureController {
    @GetMapping("/secure/resource") public String secureResource() { return "This is a secure Resource Server endpoint"; }
    @GetMapping("/secure/jwt") public String secureJwt() { return "This is a secure custom JWT endpoint"; }
}
