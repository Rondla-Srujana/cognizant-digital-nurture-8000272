package com.example.auth.jwt;
import com.example.auth.config.JwtConfig;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Component;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Date;

@Component
public class JwtTokenProvider {
    private final JwtConfig jwtConfig;
    public JwtTokenProvider(JwtConfig jwtConfig) { this.jwtConfig = jwtConfig; }
    private SecretKey getSigningKey() { return Keys.hmacShaKeyFor(jwtConfig.getSecret().getBytes(StandardCharsets.UTF_8)); }
    public String createToken(String username) {
        Claims claims = Jwts.claims().subject(username).build();
        Date now = new Date();
        return Jwts.builder().claims(claims).issuedAt(now).expiration(new Date(now.getTime() + 3600000)).signWith(getSigningKey()).compact();
    }
    public boolean validateToken(String token) {
        try { Jwts.parser().verifyWith(getSigningKey()).build().parseSignedClaims(token); return true; } catch (Exception e) { return false; }
    }
    public Authentication getAuthentication(String token) {
        String username = Jwts.parser().verifyWith(getSigningKey()).build().parseSignedClaims(token).getPayload().getSubject();
        return new UsernamePasswordAuthenticationToken(new User(username, "", Collections.emptyList()), token, Collections.emptyList());
    }
}
